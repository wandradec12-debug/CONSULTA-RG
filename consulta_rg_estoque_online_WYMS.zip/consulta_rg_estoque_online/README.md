# Consulta RG • Estoque — versão online

Sistema completo para:
- login de administrador;
- importação diária de Excel/CSV;
- substituição da base ativa;
- consulta de RG pelo celular;
- leitura de QR Code pela câmera;
- indicação da posição de estoque;
- histórico das importações;
- indicadores básicos;
- registro das consultas.

## 1. Testar no computador
Requisitos: Docker Desktop.

```bash
docker compose up --build
```

Abra `http://localhost:8000`.

Usuário padrão: `admin`
Senha padrão: `admin123`

**Troque a senha antes de disponibilizar na internet.**

## 2. Planilha padrão — WYMS

O sistema foi ajustado para aceitar diretamente a exportação WYMS enviada como padrão.

Arquivo analisado:
- 43.769 linhas
- 38 colunas
- 40.600 RGs preenchidos e únicos
- 3.169 linhas sem RG
- RG: `RG`
- posição: `LOCALIZAÇÃO`
- produto: `PRODUTO`
- código: `COD. PRODUTO`
- quantidade: `QTD CX`
- peso: `PESO`
- produção: `DATA DE PRODUÇÃO`
- validade: `DATA DE VALIDADE`
- situação: `SITUAÇÃO`
- câmara: `CÂMARA`
- área: `ÁREA`
- temperatura: `TEMPERATURA`

O sistema preserva os demais campos da exportação para uso futuro.

**Importante:** nesta base, cada RG preenchido aparece uma única vez, o que torna o RG adequado como chave de consulta da caixa/palete.

RG deve ser tratado como texto para preservar zeros à esquerda.

## 3. Publicação
A aplicação foi preparada em container. Pode ser publicada em um provedor de cloud que aceite Docker e PostgreSQL. Na publicação, configure:
- DATABASE_URL
- SECRET_KEY
- ADMIN_USER
- ADMIN_PASSWORD

Também é necessário HTTPS para uso confiável da câmera do celular.

## 4. Próxima evolução recomendada
Para uma operação de CD, a próxima etapa é adicionar:
1. usuários separados (Administrador / Operador);
2. QR Code também na etiqueta da posição;
3. confirmação de posição física;
4. registro de divergência RG x posição;
5. dashboard de acuracidade;
6. exportação de divergências;
7. trilha de auditoria;
8. versionamento das bases em vez de apagar a anterior;
9. integração com WMS/ERP, se disponível;
10. domínio interno e controle de acesso conforme política de TI da empresa.
