import os, io, hashlib, secrets
from datetime import datetime, timezone
import pandas as pd
import jwt
from fastapi import FastAPI, Request, UploadFile, File, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, ForeignKey, func
from sqlalchemy.orm import declarative_base, sessionmaker, Session

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./estoque.db")
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

class ImportBatch(Base):
    __tablename__ = "import_batches"
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    rows = Column(Integer, default=0)
    imported_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    checksum = Column(String(64), nullable=False)

class StockItem(Base):
    __tablename__ = "stock_items"
    id = Column(Integer, primary_key=True)
    rg = Column(String(120), index=True, nullable=True)
    etiqueta_palete = Column(String(120), index=True)
    posicao = Column(String(120), index=True)
    cod_produto = Column(String(80))
    produto = Column(String(255))
    quantidade = Column(String(80))
    peso = Column(String(80))
    data_producao = Column(String(50))
    validade = Column(String(50))
    status = Column(String(120))
    shelf_life = Column(String(80))
    shelf = Column(String(80))
    origem = Column(String(120))
    temperatura = Column(String(80))
    data_criacao = Column(String(80))
    data_modificacao = Column(String(80))
    camara = Column(String(80))
    modificado_por = Column(String(255))
    area = Column(String(120))
    loc_bloq = Column(String(120))
    movimentacao = Column(String(120))
    loc_srp = Column(String(120))
    sublocal = Column(String(120))
    n_kit = Column(String(80))
    estrutura = Column(String(120))
    capacidade = Column(String(80))
    sif = Column(String(80))
    bloqueio_atual_grupo = Column(String(120))
    bloqueio_atual_subgrupo = Column(String(120))
    bloqueio_atual_usuario = Column(String(255))
    bloqueio_atual_data = Column(String(80))
    bloqueio_anterior_grupo = Column(String(120))
    bloqueio_anterior_subgrupo = Column(String(120))
    bloqueio_anterior_usuario = Column(String(255))
    bloqueio_anterior_data = Column(String(80))
    motivo = Column(String(255))
    observacao = Column(Text)
    import_id = Column(Integer, ForeignKey("import_batches.id"), index=True)

class Consultation(Base):
    __tablename__ = "consultations"
    id = Column(Integer, primary_key=True)
    rg = Column(String(120), index=True)
    found = Column(Integer, default=0)
    consulted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Consulta RG • Estoque")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

def db():
    s = SessionLocal()
    try: yield s
    finally: s.close()

def token_for(user):
    return jwt.encode({"sub": user, "exp": datetime.now(timezone.utc).timestamp()+28800}, SECRET_KEY, algorithm="HS256")

def current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token: return None
    try: return jwt.decode(token, SECRET_KEY, algorithms=["HS256"]).get("sub")
    except Exception: return None

@app.get("/", response_class=HTMLResponse)
def home(request: Request, user=Depends(current_user)):
    if not user: return RedirectResponse("/login", 302)
    return templates.TemplateResponse("index.html", {"request": request, "user": user})

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    if secrets.compare_digest(username, ADMIN_USER) and secrets.compare_digest(password, ADMIN_PASSWORD):
        r = RedirectResponse("/", 302)
        r.set_cookie("access_token", token_for(username), httponly=True, secure=False, samesite="lax")
        return r
    return RedirectResponse("/login?error=1", 302)

@app.get("/logout")
def logout():
    r = RedirectResponse("/login", 302)
    r.delete_cookie("access_token")
    return r

@app.get("/api/stats")
def stats(db: Session = Depends(db), user=Depends(current_user)):
    if not user: return JSONResponse({"error":"unauthorized"}, status_code=401)
    return {
        "rg_count": db.query(func.count(StockItem.id)).scalar() or 0,
        "imports": db.query(func.count(ImportBatch.id)).scalar() or 0,
        "last_import": (db.query(ImportBatch).order_by(ImportBatch.id.desc()).first().imported_at.isoformat()
                        if db.query(ImportBatch).first() else None)
    }

ALIASES = {
    # Identificação
    "rg":"rg",
    "registrogeral":"rg",
    "registro":"rg",
    "etiquetapalete":"etiqueta_palete",

    # Endereço
    "localizacao":"posicao",
    "posicao":"posicao",

    # Produto / quantidade
    "codproduto":"cod_produto",
    "produto":"produto",
    "qtdcx":"quantidade",
    "quantidade":"quantidade",
    "peso":"peso",

    # Datas / status
    "datadeproducao":"data_producao",
    "datadevalidade":"validade",
    "situacao":"status",
    "shelflife":"shelf_life",
    "shelf":"shelf",

    # Operação
    "origem":"origem",
    "temperatura":"temperatura",
    "datadecriacao":"data_criacao",
    "datademodificacao":"data_modificacao",
    "camara":"camara",
    "modificadopor":"modificado_por",
    "area":"area",
    "locbloq":"loc_bloq",
    "movimentacao":"movimentacao",
    "locrp":"loc_srp",
    "locsrp":"loc_srp",
    "sublocal":"sublocal",
    "nkit":"n_kit",
    "estrutura":"estrutura",
    "capacidade":"capacidade",
    "sif":"sif",

    # Bloqueios / observações
    "bloqueioatualgrupo":"bloqueio_atual_grupo",
    "bloqueioatualsubgrupo":"bloqueio_atual_subgrupo",
    "bloqueioatualusuario":"bloqueio_atual_usuario",
    "bloqueioatualdata":"bloqueio_atual_data",
    "bloqueioanteriorgrupo":"bloqueio_anterior_grupo",
    "bloqueioanteriorsubgrupo":"bloqueio_anterior_subgrupo",
    "bloqueioanteriorusuario":"bloqueio_anterior_usuario",
    "bloqueioanteriordata":"bloqueio_anterior_data",
    "motivo":"motivo",
    "observacao":"observacao",
}

def norm(s):
    import unicodedata
    s = str(s).strip().lower()
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).replace(" ","").replace("_","").replace("-","")

@app.post("/api/import")
async def import_excel(file: UploadFile = File(...), db: Session = Depends(db), user=Depends(current_user)):
    if not user: return JSONResponse({"error":"unauthorized"}, status_code=401)
    raw = await file.read()
    checksum = hashlib.sha256(raw).hexdigest()
    try:
        if file.filename.lower().endswith(".csv"):
            df = pd.read_csv(io.BytesIO(raw), dtype=str)
        else:
            df = pd.read_excel(io.BytesIO(raw), dtype=str)
    except Exception as e:
        return JSONResponse({"error":f"Não foi possível ler o arquivo: {e}"}, status_code=400)
    mapped = {}
    for c in df.columns:
        key = norm(c)
        if key in ALIASES: mapped[ALIASES[key]] = c
    if "rg" not in mapped or "posicao" not in mapped:
        return JSONResponse({"error":"A base precisa conter pelo menos as colunas RG e Posição."}, status_code=400)
    batch = ImportBatch(filename=file.filename, checksum=checksum, rows=len(df))
    db.add(batch); db.flush()
    # A base ativa passa a ser a última importação.
    db.query(StockItem).delete(synchronize_session=False)
    for _, row in df.fillna("").iterrows():
        rg = str(row[mapped["rg"]]).strip()
        if rg.lower() == "nan": rg = ""
        values = {}
        for field, col in mapped.items():
            values[field] = str(row[col]).strip() if str(row[col]).strip().lower() != "nan" else ""
        db.add(StockItem(import_id=batch.id, **values))
    db.commit()
    return {"ok":True, "rows":len(df), "filename":file.filename, "import_id":batch.id}

@app.get("/api/rg/{rg}")
def lookup(rg: str, db: Session = Depends(db), user=Depends(current_user)):
    if not user: return JSONResponse({"error":"unauthorized"}, status_code=401)
    clean = rg.strip()
    item = db.query(StockItem).filter(StockItem.rg == clean).first()
    db.add(Consultation(rg=clean, found=1 if item else 0)); db.commit()
    if not item: return {"found":False, "rg":clean}
    return {"found":True, "rg":item.rg, "etiqueta_palete":item.etiqueta_palete,
            "posicao":item.posicao, "cod_produto":item.cod_produto, "produto":item.produto,
            "quantidade":item.quantidade, "peso":item.peso, "data_producao":item.data_producao,
            "validade":item.validade, "status":item.status, "shelf_life":item.shelf_life,
            "shelf":item.shelf, "origem":item.origem, "temperatura":item.temperatura,
            "camara":item.camara, "area":item.area, "sublocal":item.sublocal, "sif":item.sif,
            "bloqueio_atual_grupo":item.bloqueio_atual_grupo,
            "bloqueio_atual_subgrupo":item.bloqueio_atual_subgrupo,
            "motivo":item.motivo, "observacao":item.observacao}

@app.get("/api/imports")
def imports(db: Session = Depends(db), user=Depends(current_user)):
    if not user: return JSONResponse({"error":"unauthorized"}, status_code=401)
    return [{"id":x.id,"filename":x.filename,"rows":x.rows,"imported_at":x.imported_at.isoformat()}
            for x in db.query(ImportBatch).order_by(ImportBatch.id.desc()).limit(20).all()]
